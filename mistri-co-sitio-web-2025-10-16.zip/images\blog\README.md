# Imágenes para la Página Blog

Esta carpeta contiene las imágenes de fondo para los artículos del blog.

## Imágenes Requeridas (3 imágenes):
- **`blog-1.jpg`** - Artículo destacado
- **`blog-2.jpg`** - Segundo artículo
- **`blog-3.jpg`** - Tercer artículo

## Especificaciones:
- **Dimensiones:** 800x600px o superior
- **Formato:** JPG o PNG
- **Tema:** Educación, liderazgo, transformación organizacional
- **Colores:** Preferiblemente tonos azules o neutros
