# Imágenes para la Página Quiénes Somos

Esta carpeta contiene las imágenes de fondo para las áreas de especialización del equipo.

## Imágenes Requeridas (4 imágenes):
- **`area-1.jpg`** - Talento Humano
- **`area-2.jpg`** - Organización y Procesos
- **`area-3.jpg`** - Financiero y Tributario
- **`area-4.jpg`** - Coaching y Desarrollo

## Especificaciones:
- **Dimensiones:** 800x600px o superior
- **Formato:** JPG o PNG
- **Tema:** Profesional, equipo de trabajo, especialización
- **Colores:** Preferiblemente tonos azules o neutros
