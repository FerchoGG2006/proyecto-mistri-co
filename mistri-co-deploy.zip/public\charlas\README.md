# Imágenes para la Página Charlas

Esta carpeta contiene las imágenes de fondo para las charlas y eventos.

## Imágenes Requeridas (3 imágenes):
- **`charla-1.jpg`** - Primera charla
- **`charla-2.jpg`** - Segunda charla
- **`charla-3.jpg`** - Tercera charla

## Especificaciones:
- **Dimensiones:** 800x600px o superior
- **Formato:** JPG o PNG
- **Tema:** Presentaciones, conferencias, eventos corporativos
- **Colores:** Preferiblemente tonos azules o neutros
